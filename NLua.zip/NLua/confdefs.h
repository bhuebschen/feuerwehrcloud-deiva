/* confdefs.h */
#define PACKAGE_NAME "NLua.Net40"
#define PACKAGE_TARNAME "nlua-net40"
#define PACKAGE_VERSION "2.x"
#define PACKAGE_STRING "NLua.Net40 2.x"
#define PACKAGE_BUGREPORT ""
#define PACKAGE_URL ""
#define PACKAGE "nlua-net40"
#define VERSION "2.x"
