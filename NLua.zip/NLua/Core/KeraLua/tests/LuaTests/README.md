LuaTests
========

Test of Lua language

+ core tests
+ test [suite](http://www.lua.org/tests/)