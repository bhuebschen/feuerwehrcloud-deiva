Legacy Lua tests
----------------

Tests that need interaction or are not good to test in every environments.