
This is Lua 5.2.3, released on 11 Nov 2013.

[![Build Status](https://secure.travis-ci.org/NLua/lua.svg?branch=master)](https://travis-ci.org/NLua/lua)

For installation instructions, license details, and
further information about Lua, see doc/readme.html.

