Building Lua52 for iPhone
=========================

+ You can build using Xcode, or to make the life easier just type on ios_build folder.
	
		make

+ This will produce libLua52.a just add to your iOS project.
+ Remember to add stdlibc++ to build your application.


