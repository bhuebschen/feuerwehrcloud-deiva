#!/bin/sh
cd Core/KeraLua
make -f Makefile.Android
cd ../../
make -f Makefile.Android

