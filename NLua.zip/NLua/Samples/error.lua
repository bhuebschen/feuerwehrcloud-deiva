require 'CLRPackage'
import 'System'
local arr = luanet.make_array(Double,{1,2})
print(arr.Length)
print(arr.Foo)
